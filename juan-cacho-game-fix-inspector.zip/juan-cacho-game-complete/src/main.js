// src/main.js
import { log } from './core/logger.js'
import { Assets } from './core/assetLoader.js'
import { Renderer } from './engine/renderer.js'
import { SceneManager } from './engine/sceneManager.js'
import { HUD } from './ui/hud.js'
import { Inventory } from './engine/inventory.js'
import { Cap1Salon } from './scenes/cap1_salon.js'
import { State } from './core/state.js'
import { Config } from './game/config.js'

async function boot(){
  const canvas = document.getElementById('gameCanvas')
  const overlay = document.getElementById('overlayCanvas')
  const hudEl = document.getElementById('hud')
  if(!canvas){ alert('Falta el canvas #gameCanvas'); return }
  if(!hudEl){ alert('Falta el contenedor #hud'); return }

  log.info('[BOOT] Comenzando…')

  // Cargar manifiesto de assets
  let manifest = null
  try{
    const res = await fetch('./src/data/assets.json', {cache:'no-store'})
    manifest = await res.json()
  }catch(err){
    log.error('No se pudo leer assets.json', err)
    toast('Error cargando assets. Revisa src/data/assets.json')
    return
  }

  try{
    await Assets.loadManifest(manifest)
    log.info('[BOOT] Assets listos:', Assets.summary())
  }catch(err){
    log.error('Fallo cargando assets', err)
    toast('Fallo cargando imágenes. Revisa la consola.')
    return
  }

  const renderer = new Renderer(canvas, Assets, overlay)
  const hud = new HUD()
  // Asegura inspector oculto al arrancar
  const insp = document.getElementById('inspector'); if(insp) insp.hidden = true
  const inventory = new Inventory(hud)
  const sceneManager = new SceneManager(renderer, hud, inventory)

  // Registrar escenas
  sceneManager.register('cap1_salon', new Cap1Salon({assets: Assets, hud, inventory}))

  // Estado y reset
  const params = new URLSearchParams(location.search)
  State.load()
  if (params.has('reset')) {
    State.reset()
  }

  const startScene = State.data.currentScene || 'cap1_salon'
  await sceneManager.change(startScene)

  // Controles
  window.addEventListener('resize', () => sceneManager.render())

  if (params.has('debug')) Config.debug.hotspots = true
  window.addEventListener('keydown', (e) => {
    const key = e.key.toLowerCase()
    if (key === 'escape') { hud.closeInspector?.(); return }
    if (key === 'h') {
      Config.debug.hotspots = !Config.debug.hotspots
      sceneManager.render()
      hud.toast(`Hotspots: ${Config.debug.hotspots ? 'ON' : 'OFF'}`)
    } else if (key === 'r') {
      newGame(sceneManager, hud)
    }
  })

  const btnReset = document.getElementById('btnReset')
  if (btnReset) btnReset.addEventListener('click', () => newGame(sceneManager, hud))

  log.info('[BOOT] OK')
}

function newGame(sceneManager, hud){
  State.reset()
  sceneManager.change('cap1_salon')
  hud.toast('Nuevo juego iniciado.')
}

function toast(msg){
  const el = document.getElementById('toast')
  if(!el) return
  el.textContent = msg
  el.hidden = false
  setTimeout(()=> el.hidden = true, 1800)
}

boot().catch(err => {
  console.error('Error fatal en boot()', err)
  const el = document.getElementById('toast')
  if(el){ el.textContent = 'Error fatal. Ver consola.'; el.hidden = false }
})
