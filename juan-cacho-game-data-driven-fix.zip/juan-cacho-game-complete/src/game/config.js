// src/game/config.js
export const Config = {
  title: 'Juan Cacho · The Game',
  debug: { hotspots: true }
}
